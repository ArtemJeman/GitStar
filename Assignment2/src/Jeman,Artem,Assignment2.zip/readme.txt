[Artem Jeman], [A00869832], [1A], [2014 03 02]

This assignment is [100]% complete.


------------------------
Question one (TriangleArea) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question two (CylinderStats) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question three (Bookshelf) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question four (BoxTest) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question five (TrafficLight) status:

[complete]
[explanation if not complete, what is working/not working]
