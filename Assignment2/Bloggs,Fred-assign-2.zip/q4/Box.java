package q4;

public class Box {
    private int h, w, z;
    private boolean full;
    
    public Box(int H, int W, int Z, boolean Full){
        h = H;
        w = W; 
        z = Z;
        full = Full; 
       
    }
    
    public int getH(){
        return h;    
    }
    
    public void setH(int h){
       this.h = h; 
    }
    
    public int getW(){
        return w;    
    }
    
    public void setW(int w){
       this.w = w; 
    }
    
    public int getZ(){
        return z;    
    }
    
    public void setZ(int z){
       this.z = z; 
    }
    
    public boolean getFull(){
        return full;    
    }
    
    public void setFull(boolean full){
       this.full = full; 
    }
    
    public String toString(){
        return  ( "The Height: " + h +"The Width: " + w  +"The Depth: " + z  +"Full?" + full);
    }
}
