package q1;

import java.util.Scanner;
import java.text.DecimalFormat;

/**
 * <p>This program figures out the area and the perimeter of a triangle.</p>
 *
 * @author Artem Jeman
 * @version 1.0
 */
public class TriangleArea {
    /**
     * <p>This is the main method (entry point) that gets called by the JVM.</p>
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        DecimalFormat f = new DecimalFormat("0.000");
        
        double x;
        double y;
        double z; 
        
        System.out.println("Enter the first length of the triangle");
        x = scan.nextDouble();
        System.out.println("Enter the second length of the triangle");
        y = scan.nextDouble();
        System.out.println("Enter the third length of the triangle");
        z = scan.nextDouble();
        
        double perimeter = x+y+z;
        double s = perimeter/2;
        
        System.out.println("The perimeter of the triangle is: "+ f.format(perimeter));
        
        double area = Math.sqrt(s * (s - x) * (s - y) * (s - z));
        
        System.out.println("The area of the triangle is: "+ f.format(area));
        
        scan.close();
    }

};
