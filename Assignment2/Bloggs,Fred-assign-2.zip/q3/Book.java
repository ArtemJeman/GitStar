package q3;

public class Book {
    private String title, author, publisher;
    private int copydate;
    
    public Book(String Title, String Author, String Publisher, int Copydate)
    {
        title = Title;
        author = Author; 
        publisher = Publisher; 
        copydate = Copydate;           
    }
    
    public Book(){
        title = "";
        author = "";
        publisher = ""; 
        copydate = 0; 
    }
    
    public String getTitle(){
        return title;
         }
    
    public void setTitle(String title){
        this.title = title;
    }
    
    public String getAuthor(){
        return author;
         }
    
    public void setAuthor(String author){
        this.author = author; 
         }
    
    public String getPublisher(){
        return publisher;
         }
    
    public void setPublisher(String publisher){
        this.publisher = publisher;
    }
    
    public int getCopydate(){
        return copydate;
        }
    
    public void setCopydate(int copydate){
        this.copydate = copydate;
        
    }
    
    public String toString(){
        return  (title +"\n" + author  +"\n" + publisher  +"\n" + copydate);
    }
}


